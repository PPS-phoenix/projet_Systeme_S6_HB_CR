#ifndef _PIPE_H
#define _PIPE_H

void execPipe(char ***command, int npipe, int *tabArgs, char *history_file_path, char* dir );

#endif
