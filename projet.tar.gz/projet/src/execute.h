#ifndef _EXECUTE_H
#define _EXECUTE_H

int execute(char **args, int nargs, char *history_file_path, char * dir);

#endif

