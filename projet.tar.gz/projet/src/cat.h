#ifndef _CAT_H
#define _CAT_H

/* Fonction : cat 
 * Entrees : une chaine d'arguments,  nombre d'arguments 
 * Sortie : aucune
 * 
 * Execute la commande cat, gère l'option -n
 */

void cat(char **args, int nargs);

#endif
