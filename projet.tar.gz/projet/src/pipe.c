#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>

#include <fcntl.h>

#include "pipe.h"
#include "parsing.h"
#include "cat.c"
#include "touch.c"

#define BUFF 1024 
#define PATH_SIZE 1024
#define MAX_ARGS_SIZE  512


void execPipe(char ***command, int npipe, int *tabArgs, char *history_file_path, char* dir ){

   int pipes[npipe*2];
   int j = 0, i = 0, k = 0;
   int status;
   pid_t pid;
   int      npaths;
   char     *path;
   char     **paths_exe;
   char     **paths;	

   pipe(pipes);
   if(npipe > 2)
   {
      for(i=1 ; i < npipe ; i++)  
      {
	 if(pipe(pipes + (i*2)) < 0)
	 {
	    perror("error while piping");
	    exit(EXIT_FAILURE);
	 }
      }  
   }
   
      
   for(i = 0 ; i < npipe+1 ; i=i+1)
   {

      pid=fork();
      if(pid == 0)
      {
	 if(i < npipe)
	 {
	    if(dup2(pipes[(i*2) +1],1) == -1)
	    {
	       perror("read - dup2 failed");
	       exit(EXIT_FAILURE);
	    }
	 }

	 if(i != 0)
	 {
	    if(dup2(pipes[(i*2) -2],0) == -1)
	    {
	       perror("write - dup2 failed");
	       exit(EXIT_FAILURE);
	    }
	 }
	 
	 for(k=0; k < (npipe*2) ; k++)
	 {
	    close(pipes[k]);
	 }
      }
      else if(pid < 0)
      {
	 printf("\nErreur process.\n");
	 exit(EXIT_FAILURE);
      }
      
      /* Ici on execute la commande */
   
      /* gestion de CD */
      if(!strcmp(command[j][0],"cd")){
         getcwd(dir, PATH_SIZE); /* On met à jour le répertoire courant à afficher */
      }
     

      /* fonction exit */
      if(!strcmp(command[j][0], "exit")) {
         exit(0);
      }

            
      /* gestion de history */
      if(!strcmp(command[j][0], "history")) {
	 int c = 0;
	 FILE *history_file_d;
	 char     *car;
	 car = (char*) malloc(BUFF);

	 history_file_d = fopen(history_file_path , "r");
	 while(fgets(car, BUFF, history_file_d)) {
	    c++;
	    printf("%4d    %s", c, car);
	 }

	 fclose(history_file_d);
      }
      
      if(!strcmp(command[j][0], "copy")) {
	 printf("Copy TD1\n");
      }
      

      /* fonction cat */
      if(!strcmp(command[j][0], "cat")) {
	 cat(command[j],tabArgs[j]);
      }

      /* Gestion de touch */
      if(!strcmp(command[j][0], "touch")) {
	 touch(command[j],tabArgs[j]);
      }

      /* Gestion du PATH */
	   
      path = (char*) malloc(BUFF);
      strcpy(path, getenv("PATH"));

      npaths = getnpaths(path);

      paths = (char**) malloc((npaths+1)*sizeof(char*));
      for(i = 0; i < npaths+1; i++) paths[i] = (char*) malloc(MAX_ARGS_SIZE*sizeof(char));
      getpaths(path, paths);
	 
      paths_exe = (char**) malloc((npaths+1)*sizeof(char*));
      for(i = 0; i < npaths+1; i++) paths_exe[i] = (char*) malloc(MAX_ARGS_SIZE*sizeof(char));
      getexepaths(command[j][0], paths_exe, paths, npaths);

      for(i = 0; i < npaths; i++) {
	 if (execv(paths_exe[i], command[j])) {
	 }
      }

   }

      

   /* On ferme tous les pipes */
   for(k=0; k < (npipe*2) ; k++)
   {
      close(pipes[k]);
   }

   for(k = 0; k < npipe +1 ; k++)
   {
      wait(&status);
   }
}
